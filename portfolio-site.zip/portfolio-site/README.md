# Portfolio Website

A responsive portfolio + resume website for Khushboo Pal.

## Features
- About Me, Projects, Services, Contact sections
- Responsive design
- Dynamic project rendering via JavaScript
- Contact form integration
- Simple, clean UI

## Setup
1. Upload to GitHub
2. Go to Settings > Pages
3. Set source as main branch
4. View your live site!
